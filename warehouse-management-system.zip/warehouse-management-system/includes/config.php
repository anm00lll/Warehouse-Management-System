<?php
  /**
   * This file contains the core configuration for the application.
   */

  // Define the base URL of your project.
  // This makes all links and asset paths work correctly from any directory.
  // --- IMPORTANT: Make sure this path matches your project folder in htdocs ---
  define('BASE_URL', '/warehouse-management-system/');

?>
