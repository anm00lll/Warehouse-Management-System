<?php
  /**
   * This is the global footer file for the application.
   * It closes the main content wrapper and the primary HTML tags.
   * It also includes the main JavaScript file using the correct path.
   */
?>
    </main> <!-- This closes the <main class="main-content"> tag from header.php -->
    
    <!-- Main application script file (FIXED PATH) -->
    <script src="<?php echo BASE_URL; ?>assets/js/script.js"></script>
</body>
</html>
